package org.kgitbank.emp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kgitbank.emp.model.EmpDao;
import org.kgitbank.emp.model.EmpVO;

@WebServlet("/Emp.do")
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private EmpDao empDao;
	
    public EmpServlet() {
        super();
        empDao = new EmpDao();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		String url = "";
		
		// ?action=list 사원목록
		if("list".equals(action)) {	
			List<EmpVO> empList = empDao.getEmpList();
			request.setAttribute("empList", empList);
			url = "/empList.jsp";
		}
		// ?action=view 사원조회
		if("view".equals(action)) {
			int employeeId = Integer.parseInt(request.getParameter("employeeId"));
			EmpVO emp = empDao.getEmpInfo(employeeId);
			request.setAttribute("emp", emp);
			url = "/empView.jsp";
		}
		request.getRequestDispatcher(url).forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
