package org.kgitbank.emp.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.*;
import javax.sql.DataSource;

public class EmpDao {
	static {
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("드라이버 로드 성공"); /* SQL접속하는부분 */
			
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
	}
	
	private Connection getConnection() {
		DataSource ds = null;
		Connection con = null;
		try {
			Context ctx = new InitialContext(); 						/* Context:서버 라고 생각 */
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/Oracle"); 	/* lookup:찾는다 context.xml에 jdbc.Oracle로 정의했기 때문에 */
			con = ds.getConnection(); 									/* 커넥션풀에서 커넥션 가져오는 부분 */
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	private void closeConnection (Connection con) {
		if(con != null) {
			try {
				con.close(); /* 커넥션 반납해주는 부분 */
			}catch(Exception e) {}
		}
	}
	
	/* 사원 목록 조회 */
	public List<EmpVO> getEmpList(){
		List<EmpVO> empList = new ArrayList<>();
		Connection con = null;
		
			try {
			con = getConnection();
			String sql = "select * from employees";
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				EmpVO emp = new EmpVO();
				emp.setEmployeeId(rs.getInt("employee_id"));
				emp.setFirstName(rs.getString("first_name"));
				emp.setLastName(rs.getString("last_name"));
				emp.setEmail(rs.getString("email"));
				emp.setPhoneNumber(rs.getString("phone_number"));
				emp.setHireDate(rs.getDate("hire_date"));
				emp.setJobId(rs.getString("job_id"));
				emp.setSalary(rs.getDouble("salary"));
				emp.setCommissionPct(rs.getDouble("commission_pct"));
				emp.setManagerId(rs.getInt("manager_id"));
				emp.setDepartmentId(rs.getInt("department_id"));
				empList.add(emp);
			}
			}catch(SQLException e) {
				e.printStackTrace();
			}finally {
				closeConnection(con);
			}
			return empList;
	}
	
	/* 사원 정보 검색 */
	public EmpVO getEmpInfo(int employeeId) {
		EmpVO emp = new EmpVO();
		Connection con = null;
		try {
			con = getConnection();
			String sql = "select * from employees where employee_id = ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, employeeId); /*첫번째 물음표에 사원번호를 세팅하겠다*/
			ResultSet rs = stmt.executeQuery();
			
			/*쿼리문 결과가 1개*/
			if(rs.next()) {
				emp.setEmployeeId(rs.getInt("employee_id"));
				emp.setFirstName(rs.getString("first_name"));
				emp.setLastName(rs.getString("last_name"));
				emp.setEmail(rs.getString("email"));
				emp.setPhoneNumber(rs.getString("phone_number"));
				emp.setHireDate(rs.getDate("hire_date"));
				emp.setJobId(rs.getString("job_id"));
				emp.setSalary(rs.getDouble("salary"));
				emp.setCommissionPct(rs.getDouble("commission_pct"));
				emp.setManagerId(rs.getInt("manager_id"));
				emp.setDepartmentId(rs.getInt("department_id"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		} finally{
			closeConnection(con);
		}
		return emp;
	}
	
	
}
