package org.kgitbank.emp.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.kgitbank.emp.model.EmpDao;
import org.kgitbank.emp.model.EmpVO;
import org.kgitbank.member.model.MemberVO;

@WebServlet("/Emp.do")
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private EmpDao empDao;
	
    public EmpServlet() {
        super();
        empDao = new EmpDao();
    }

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		String url = "";
		
		// ?action=list 사원목록
		if("list".equals(action)) {	
			List<EmpVO> empList = empDao.getEmpList();
			request.setAttribute("empList", empList);
			url = "/emp/empList.jsp";
		}
		
		// ?action=view 사원조회
		if("view".equals(action)) {
			int employeeId = Integer.parseInt(request.getParameter("employeeId"));
			EmpVO emp = empDao.getEmpInfo(employeeId);
			request.setAttribute("emp", emp);
			url = "/emp/empView.jsp";
		}
		
		// ?action=search 사원검색
		if("search".equals(action)) {
			String firstName = request.getParameter("firstName");
			List<EmpVO> empList = empDao.getEmpList(firstName);
			request.setAttribute("empList", empList);
			url = "/emp/empList.jsp";
		}
		
		// ?action=insert 입력
		if("insert".equals(action)) {
			request.setAttribute("jobList", empDao.getJobList());
			request.setAttribute("manList", empDao.getManagerList());
			request.setAttribute("deptList", empDao.getDepartmentList());
			url = "/emp/empInsert.jsp";
		}
		
		// ?action=update 입력
		if("update".equals(action)) {
			request.setAttribute("jobList", empDao.getJobList());
			request.setAttribute("manList", empDao.getManagerList());
			request.setAttribute("deptList", empDao.getDepartmentList());
			// 사원의 정보를 넣어야 업데이트 할 수 있기 때문에 
			request.setAttribute("emp", empDao.getEmpInfo(Integer.parseInt(request.getParameter("employeeId"))));
			url = "/emp/empInsert.jsp";
		}
		
		// ?action=delete 입력
		if("delete".equals(action)) {
			int employeeId = Integer.parseInt(request.getParameter("employeeId"));
			
			request.setAttribute("deptCount", empDao.getManagerCountInDepartments(employeeId));
			request.setAttribute("empCount", empDao.getManagerCountInEmployees(employeeId));
			request.setAttribute("emp", empDao.getEmpInfo(employeeId)); // 사원정보 
			url = "/emp/empDelete.jsp";
		}
		
		request.getRequestDispatcher(url).forward(request, response);
	}


	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		
		if("insert".equals(action)) {
			int employeeId = Integer.parseInt(request.getParameter("employeeId"));
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			String email = request.getParameter("email");
			String phoneNumber = request.getParameter("phoneNumber");
			java.sql.Date hireDate = null;
			
			try {
				SimpleDateFormat tool = new SimpleDateFormat("yyyy-mm-dd");
				hireDate = new java.sql.Date(tool.parse(request.getParameter("hireDate")).getTime());
			} catch(ParseException e) {
				e.printStackTrace();
			}

			String jobId = request.getParameter("jobId");
			double salary = Double.parseDouble(request.getParameter("salary"));
			double commissionPct = Double.parseDouble(request.getParameter("commissionPct"));
			int managerId = Integer.parseInt(request.getParameter("employeeId"));
			int departmentId = Integer.parseInt(request.getParameter("departmentId"));
			
			// 파라미터에 세팅해서 데이터 저장 넘겨주기
			EmpVO emp = new EmpVO();
			
			emp.setEmployeeId(employeeId);
			emp.setFirstName(firstName);
			emp.setLastName(lastName);
			emp.setEmail(email);
			emp.setPhoneNumber(phoneNumber);
			emp.setHireDate(hireDate);
			emp.setJobId(jobId);
			emp.setSalary(salary);
			emp.setCommissionPct(commissionPct);
			emp.setManagerId(managerId);
			emp.setDepartmentId(managerId);
			emp.setDepartmentId(departmentId);
			
			/* DB에 입력 */
			empDao.insertEmployee(emp);
			
			/* 목록을 보겠다는 재요청을 보낸다 */
			response.sendRedirect("/JDBC/Emp.do?action=list");
			
		}
		
		// 사원 정보 수정
		if("update".equals(action)) {
			
			int employeeId = Integer.parseInt(request.getParameter("employeeId"));
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			String email = request.getParameter("email");
			String phoneNumber = request.getParameter("phoneNumber");
			java.sql.Date hireDate = null;
			
			try {
				SimpleDateFormat tool = new SimpleDateFormat("yyyy-mm-dd");
				hireDate = new java.sql.Date(tool.parse(request.getParameter("hireDate")).getTime());
			} catch(ParseException e) {
				e.printStackTrace();
			}

			String jobId = request.getParameter("jobId");
			double salary = Double.parseDouble(request.getParameter("salary"));
			double commissionPct = Double.parseDouble(request.getParameter("commissionPct"));
			int managerId = Integer.parseInt(request.getParameter("employeeId"));
			int departmentId = Integer.parseInt(request.getParameter("departmentId"));
			
			// 파라미터에 세팅해서 데이터 저장 넘겨주기
			EmpVO emp = new EmpVO();
			
			emp.setEmployeeId(employeeId);
			emp.setFirstName(firstName);
			emp.setLastName(lastName);
			emp.setEmail(email);
			emp.setPhoneNumber(phoneNumber);
			emp.setHireDate(hireDate);
			emp.setJobId(jobId);
			emp.setSalary(salary);
			emp.setCommissionPct(commissionPct);
			emp.setManagerId(managerId);
			emp.setDepartmentId(managerId);
			emp.setDepartmentId(departmentId);
			empDao.updateEmployee(emp);
			
			//수정 후 수정결과를 확인할 수 있는 요청으로 리다이렉트
			response.sendRedirect("/JDBC/Emp.do?action=list");
			
		}
		
		// 사원 정보 삭제
		if("delete".equals(action)) {
			int employeeId = Integer.parseInt(request.getParameter("employeeId"));
			empDao.deleteEmployee(employeeId);
			response.sendRedirect("/JDBC/Emp.do?action=list");	
		}
		
	}

}
