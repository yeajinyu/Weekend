package org.kgitbank.emp.model;

public class DeptVO {
	
	/* MVC 중 모델(M) 부분  값을 가져옴*/ 
	private int departmentId;
	private String departmentName;
	
	// set, get 메서드 추가
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
	
}