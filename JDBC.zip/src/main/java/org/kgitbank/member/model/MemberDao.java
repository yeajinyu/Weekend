package org.kgitbank.member.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.*;
import javax.sql.DataSource;

public class MemberDao {
	static {
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("드라이버 로드 성공"); /* SQL접속하는부분 */
			
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
	}
	
	private Connection getConnection() {
		DataSource ds = null;
		Connection con = null;
		try {
			Context ctx = new InitialContext(); 						/* Context:서버 라고 생각 */
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/Oracle"); 	/* lookup:찾는다 context.xml에 jdbc.Oracle로 정의했기 때문에 */
			con = ds.getConnection(); 									/* 커넥션풀에서 커넥션 가져오는 부분 */
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	private void closeConnection (Connection con) {
		if(con != null) {
			try {
				con.close(); /* 커넥션 반납해주는 부분 */
			}catch(Exception e) {}
		}
	}
	
	/* 관리자 회원가입 */
	public void insertMember(MemberVO member) {
		Connection con = null;
		try {
			con = getConnection();
			String sql = "insert into member values(?,?,?,?,?)";
			
			/*쿼리문에 insert 데이터 세팅*/
			PreparedStatement stmt = con.prepareStatement(sql);
			
			stmt.setString(1, member.getUserid());
			stmt.setString(2, member.getName());
			stmt.setString(3, member.getPassword());
			stmt.setString(4, member.getEmail());
			stmt.setString(5, member.getAddress());
			
			stmt.executeUpdate();
			
		} catch(SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("관리자 정보 입력 실패");
		} finally {
			closeConnection(con);
		}
		
	}
	
	/* 아이디에 해당하는 비밀번호 리턴 */
	public String getPassword(String userid) {
		String dbpw = null;
		Connection con = null;
		try {
			con = getConnection();
			String sql = "select password from member where userid like ?";
			
			/*쿼리문에 insert 데이터 세팅*/
			PreparedStatement stmt = con.prepareStatement(sql);
			
			stmt.setString(1, userid);

			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				dbpw = rs.getString(1);
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("비밀번호 조회 실패");
		} finally {
			closeConnection(con);
		}
		return dbpw;
		
	}
	
	
	
}






















