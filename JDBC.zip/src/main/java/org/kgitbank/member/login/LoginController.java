package org.kgitbank.member.login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.kgitbank.member.model.MemberDao;


@WebServlet("/Login.do")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberDao memberDao;
	
    public LoginController() {
        super();
        memberDao = new MemberDao();
    }


	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getSession().invalidate();
		response.sendRedirect("/JDBC/form.jsp");
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");
		String dbpw = memberDao.getPassword(userid);
		
		if(dbpw != null && dbpw.equals(password)) {
			//로그인
			HttpSession session = request.getSession();
			session.setAttribute("userid", userid);
			response.sendRedirect("/JDBC/form.jsp");
			
		}else {
			request.setAttribute("message", "아이디 또는 비밀번호가 다릅니다.");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}
		
	}

}
