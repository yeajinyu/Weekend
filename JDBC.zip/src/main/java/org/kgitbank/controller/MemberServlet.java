package org.kgitbank.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.kgitbank.member.model.MemberDao;
import org.kgitbank.member.model.MemberVO;

@WebServlet("/Member.do")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private MemberDao memberDao;

	public MemberServlet() {
		super();
		memberDao = new MemberDao();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");

		if ("insert".equals(action)) {

			/*
			 * String userid = request.getParameter("userid"); String name =
			 * request.getParameter("name"); String password =
			 * request.getParameter("password"); String email =
			 * request.getParameter("email"); String address =
			 * request.getParameter("address");
			 * 
			 * // 파라미터에 세팅해서 데이터 저장 넘겨주기 ManagerVO__ man = new ManagerVO__();
			 * 
			 * man.setUserid(userid); man.setPassword(password); man.setName(name);
			 * man.setEmail(email); man.setAddress(address);
			 * 
			 * DB에 입력 memberDao.insertManager(man);
			 * 
			 * 목록을 보겠다는 재요청을 보낸다 response.sendRedirect("/JDBC/Manager.do?action=list");
			 */
			
			MemberVO member = new MemberVO();
			member.setUserid(request.getParameter("userid"));
			member.setName(request.getParameter("name"));
			member.setPassword(request.getParameter("password"));
			member.setEmail(request.getParameter("email"));
			member.setAddress(request.getParameter("address"));
			
			memberDao.insertMember(member);
			
			response.sendRedirect("/JDBC/login.jsp");
		}

	}

}
