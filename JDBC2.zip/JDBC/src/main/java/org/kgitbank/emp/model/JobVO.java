package org.kgitbank.emp.model;

public class JobVO {
	
	/* MVC 중 모델(M) 부분  값을 가져옴*/ 
	private String jobId;
	private String jobTitle;
	
	// set, get 메서드 추가
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	
	
}