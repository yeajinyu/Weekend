package org.kgitbank.emp.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.*;
import javax.sql.DataSource;

public class EmpDao {
	static {
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("드라이버 로드 성공"); /* SQL접속하는부분 */
			
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
	}
	
	private Connection getConnection() {
		DataSource ds = null;
		Connection con = null;
		try {
			Context ctx = new InitialContext(); 						/* Context:서버 라고 생각 */
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/Oracle"); 	/* lookup:찾는다 context.xml에 jdbc.Oracle로 정의했기 때문에 */
			con = ds.getConnection(); 									/* 커넥션풀에서 커넥션 가져오는 부분 */
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	private void closeConnection (Connection con) {
		if(con != null) {
			try {
				con.close(); /* 커넥션 반납해주는 부분 */
			}catch(Exception e) {}
		}
	}
	
	/* 사원 목록 조회 */
	public List<EmpVO> getEmpList(){
		List<EmpVO> empList = new ArrayList<>();
		Connection con = null;
		
			try {
			con = getConnection();
			String sql = "select * from employees";
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				EmpVO emp = new EmpVO();
				emp.setEmployeeId(rs.getInt("employee_id"));
				emp.setFirstName(rs.getString("first_name"));
				emp.setLastName(rs.getString("last_name"));
				emp.setEmail(rs.getString("email"));
				emp.setPhoneNumber(rs.getString("phone_number"));
				emp.setHireDate(rs.getDate("hire_date"));
				emp.setJobId(rs.getString("job_id"));
				emp.setSalary(rs.getDouble("salary"));
				emp.setCommissionPct(rs.getDouble("commission_pct"));
				emp.setManagerId(rs.getInt("manager_id"));
				//emp.setDepartmentId(rs.getInt("department_id"));
				empList.add(emp);
			}
			}catch(SQLException e) {
				e.printStackTrace();
			}finally {
				closeConnection(con);
			}
			return empList;
	}
	
	/* 사원 정보 검색 */
	public EmpVO getEmpInfo(int employeeId) {
		EmpVO emp = new EmpVO();
		Connection con = null;
		try {
			con = getConnection();
			String sql = "select * from employees where employee_id = ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, employeeId); /*첫번째 물음표에 사원번호를 세팅하겠다*/
			ResultSet rs = stmt.executeQuery();
			
			/*쿼리문 결과가 1개*/
			if(rs.next()) {
				emp.setEmployeeId(rs.getInt("employee_id"));
				emp.setFirstName(rs.getString("first_name"));
				emp.setLastName(rs.getString("last_name"));
				emp.setEmail(rs.getString("email"));
				emp.setPhoneNumber(rs.getString("phone_number"));
				emp.setHireDate(rs.getDate("hire_date"));
				emp.setJobId(rs.getString("job_id"));
				emp.setSalary(rs.getDouble("salary"));
				emp.setCommissionPct(rs.getDouble("commission_pct"));
				emp.setManagerId(rs.getInt("manager_id"));
				//emp.setDepartmentId(rs.getInt("department_id"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		} finally{
			closeConnection(con);
		}
		return emp;
	}
	
	/* 이름으로 검색 */
	public List<EmpVO> getEmpList(String firstName){
		List<EmpVO> empList = new ArrayList<>();
		Connection con = null;
		try {
			con = getConnection();
			/*String sql = "select * from employees where first_name like %?%";*/
			
			/*아래 동작대로 firstName을 빼야 돌아간다*/
			firstName = "%" + firstName + "%";
			String sql = " select * from employees where first_name like ? ";
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, firstName); /*첫번째 물음표에 사원번호를 세팅하겠다*/
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				EmpVO emp = new EmpVO();
				emp.setEmployeeId(rs.getInt("employee_id"));
				emp.setFirstName(rs.getString("first_name"));
				emp.setLastName(rs.getString("last_name"));
				emp.setEmail(rs.getString("email"));
				emp.setPhoneNumber(rs.getString("phone_number"));
				emp.setHireDate(rs.getDate("hire_date"));
				emp.setJobId(rs.getString("job_id"));
				emp.setSalary(rs.getDouble("salary"));
				emp.setCommissionPct(rs.getDouble("commission_pct"));
				emp.setManagerId(rs.getInt("manager_id"));
				//emp.setDepartmentId(rs.getInt("department_id"));
				empList.add(emp);
			}

		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con);
		}
		
		return empList;
	}
	
	/* 직무목록 리턴하는 메소드 */
	public List<JobVO> getJobList(){
		List<JobVO> jobList = new ArrayList<>();
		Connection con = null;
		try {
			con = getConnection();
			String sql = "select * from jobs";
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				JobVO job = new JobVO();
				job.setJobId(rs.getString("job_id"));
				job.setJobTitle(rs.getString("job_title"));
				jobList.add(job);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con);
		}
		
		return jobList;
	}
	
	/* 사원번호,이름, 성 합친거*/
	public List<EmpVO> getManagerList(){
		List<EmpVO> manList = new ArrayList<>();
		Connection con = null;
		try {
			con = getConnection();
			String sql 	= "select employee_id, first_name|| '' ||last_name as manager_name "
						+ "from employees "
						+ "where employee_id in "
						+ "(select distinct manager_id from employees)";
			
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				EmpVO man = new EmpVO();
				man.setEmployeeId(rs.getInt("employee_id"));
				man.setFirstName(rs.getString("manager_name"));
				manList.add(man);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con);
		}
		
		return manList;
	}
	
	/* 부서목록 가져오기 */
	public List<DeptVO> getDepartmentList(){
		List<DeptVO> deptList = new ArrayList<>();
		Connection con = null;
		try {
			con = getConnection();
			String sql = "select * from departments ";
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				DeptVO dept = new DeptVO();
				dept.setDepartmentId(rs.getInt("department_id"));
				dept.setDepartmentName(rs.getString("department_name"));
				deptList.add(dept);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con);
		}
		
		return deptList;
	}
	
	/* 사원정보 insert */
	public void insertEmployee(EmpVO emp) {
		Connection con = null;
		try {
			con = getConnection();
			String sql = "insert into employees values(?,?,?,?,?,?,?,?,?,?)";
			
			/*쿼리문에 insert 데이터 세팅*/
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, emp.getEmployeeId());
			stmt.setString(2, emp.getFirstName());
			stmt.setString(3, emp.getLastName());
			stmt.setString(4, emp.getEmail());
			stmt.setString(5, emp.getPhoneNumber());
			stmt.setDate(6, emp.getHireDate());
			stmt.setString(7, emp.getJobId()); 
			stmt.setDouble(8, emp.getSalary());
			stmt.setDouble(9, emp.getCommissionPct());
			stmt.setInt(10, emp.getManagerId());
			//stmt.setInt(11, emp.getDepartmentId());
			stmt.executeUpdate();
			
		} catch(SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("사원정보 입력 실패");
		} finally {
			closeConnection(con);
		}
		
	}
	
}






















