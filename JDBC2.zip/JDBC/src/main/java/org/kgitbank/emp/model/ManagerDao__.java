package org.kgitbank.emp.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.*;
import javax.sql.DataSource;

public class ManagerDao__ {
	static {
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("드라이버 로드 성공"); /* SQL접속하는부분 */
			
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
	}
	
	private Connection getConnection() {
		DataSource ds = null;
		Connection con = null;
		try {
			Context ctx = new InitialContext(); 						/* Context:서버 라고 생각 */
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/Oracle"); 	/* lookup:찾는다 context.xml에 jdbc.Oracle로 정의했기 때문에 */
			con = ds.getConnection(); 									/* 커넥션풀에서 커넥션 가져오는 부분 */
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	private void closeConnection (Connection con) {
		if(con != null) {
			try {
				con.close(); /* 커넥션 반납해주는 부분 */
			}catch(Exception e) {}
		}
	}
	
	/* 관리자 회원가입 */
	public void insertManager(ManagerVO__ man) {
		Connection con = null;
		try {
			con = getConnection();
			String sql = "insert into member values(?,?,?,?,?)";
			
			/*쿼리문에 insert 데이터 세팅*/
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, man.getUserid());
			stmt.setString(2, man.getName());
			stmt.setString(3, man.getPassword());
			stmt.setString(4, man.getEmail());
			stmt.setString(5, man.getAddress());
			
			stmt.executeUpdate();
			
		} catch(SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("관리자 정보 입력 실패");
		} finally {
			closeConnection(con);
		}
		
	}
	
	/* 관리자 목록 조회 */
	public List<ManagerVO__> getManagerList(){
		List<ManagerVO__> managerList = new ArrayList<>();
		Connection con = null;
		
			try {
			con = getConnection();
			String sql = "select * from member";
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				ManagerVO__ man = new ManagerVO__();
				
				man.setUserid(rs.getString("userid"));
				man.setName(rs.getString("name"));
				man.setPassword(rs.getString("password"));
				man.setEmail(rs.getString("email"));
				man.setAddress(rs.getString("address"));
				
				managerList.add(man);
			}
			}catch(SQLException e) {
				e.printStackTrace();
			}finally {
				closeConnection(con);
			}
			return managerList;
	}
	
	
}






















