package org.kgitbank.emp.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.SimpleAttributeSet;

import org.kgitbank.emp.model.EmpDao;
import org.kgitbank.emp.model.EmpVO;
import org.kgitbank.emp.model.ManagerDao__;
import org.kgitbank.emp.model.ManagerVO__;

@WebServlet("/Manager.do")
public class ManagerServlet__ extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private ManagerDao__ managerDao;
	
    public ManagerServlet__() {
        super();
        managerDao = new ManagerDao__();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		String url = "";
		
		// ?action=list 매니저목록
		if("list".equals(action)) {
			List<ManagerVO__> managerList = managerDao.getManagerList();
			request.setAttribute("managerList", managerList);
			url = "/managerList.jsp";
		}
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		
		if("insert".equals(action)) {
			
			String userid = request.getParameter("userid");
			String name = request.getParameter("name");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			String address = request.getParameter("address");

			// 파라미터에 세팅해서 데이터 저장 넘겨주기
			ManagerVO__ man = new ManagerVO__();
			
			man.setUserid(userid);
			man.setPassword(password);
			man.setName(name);
			man.setEmail(email);
			man.setAddress(address);
			
			/* DB에 입력 */
			managerDao.insertManager(man);
			
			/* 목록을 보겠다는 재요청을 보낸다 */
			response.sendRedirect("/JDBC/Manager.do?action=list");
			
		}
	}

}
